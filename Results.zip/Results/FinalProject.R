#==================Initial Exploration Of data==========================
setwd("~/Google Drive/Data Analytics/Assignment 6")

#Import the data set GrandSlamData.csv, sue sep = ',' because here delimiter is semi-colon
Gslam <-  read.table("GrandSlamData.csv", sep=',', header=T)
#View(Gslam)

attach(Gslam)

#Filter the unnecessary data
WinnerSet <- data.frame(surface, winner_name, winner_hand,
                    winner_ht, winner_age, winner_rank, 
                    winner_rank_points, loser_age, loser_hand, 
                    loser_rank, loser_rank_points, loser_ht, loser_name, minutes)

Final <- na.omit(WinnerSet)
write.csv(Final,"~/Google Drive/Data Analytics/Assignment 6/Final.csv")

View(Final)
attach(Final)

#Histograms

hist(winner_age, breaks = 20, xlab = "Winner Age", main = "Dataset: Final")
hist(loser_age, breaks = 20, xlab = "Loser Age", main = "Dataset: Final")
plot(winner_hand, xlab = 'Winner Hand', main = 'Dataset: Final')
plot(loser_hand, xlab = 'Loser Hand', main = 'Dataset: Final')
hist(loser_rank, xlab = "Loser Rank", main = "Dataset: Final")
plot(winner_rank, xlab = "Winner Rank", main = "Dataset: Final")
hist(loser_rank_points, breaks = 30, xlab = "Loser Rank Points", main = "Dataset: Final")
hist(winner_rank_points, breaks = 30, xlab = "Winner Rank Points", main = "Dataset: Final")

hist(winner_ht,breaks = 10, xlab = "Winner Height (cms)", main = "Dataset: Final")
hist(loser_ht,breaks = 10, xlab = "Loser Height (cms)", main = "Dataset: Final")
hist(minutes,breaks = 10, xlab = "Minutes", main = "Dataset: Final")

rm(Gslam)

install.packages("rvest")
install.packages("xml2")
install.packages("stringr")

library(readr)
library(dplyr)


library(xml2)
library(rvest)
library(stringr)
library(stringdist)

# set cols (missing some)
my.cols <- cols(
  surface = col_character(),
  winner_name = col_character(),
  winner_hand = col_character(),
  winner_ht = col_integer(),
  winner_age = col_double(),
  winner_rank = col_integer(),
  winner_rank_points = col_integer(),
  loser_age = col_double(),
  loser_hand = col_character(),
  loser_rank = col_integer(),
  loser_rank_points = col_integer(),
  loser_ht = col_integer(),
  loser_name = col_character(),
  score = col_character(),
  round = col_character()
)

# load all files with lapply and do.call (some cols don't match in all files)

Atp.matches <- do.call(bind_rows,lapply(WinnerSet, col_types = my.cols))


n.players <- 10

my.url <- 'http://www.atpworldtour.com/en/rankings/singles'
atp.players <- read_html(my.url) %>%
  html_nodes(".player-cell") %>%
  html_text() %>%
  str_replace_all('\\n','') %>%
  str_trim()

name.player <- atp.players[1:n.players]
print(name.player)


unique.players <- unique(c(as.character(winner_name), as.character(loser_name )))
idx <- amatch(name.player, unique.players, maxDist = 5)


print(data.frame(name.from.web = name.player,
                 name.from.atp = unique.players[idx] ))


#Getting the top winners and Losers

TopWinners <- sort(table(winner_name), decreasing=T)
TopLosers <- sort(table(loser_name), decreasing=T)

#=====================Clear Data=====================================
rm(list = ls())

#====================Models Below===================================

#Set the directory
setwd("~/Google Drive/Data Analytics/Assignment 6")

#Import the data set FilteredDataSet.csv, sue sep = ',' because here delimiter is semi-colon
Main <-  read.table("FilteredDataSet.csv", sep=',', header=T)
#View(Main)
attach(Main)
sample <- data.frame(surface, Win, Hand, Height, Age,
                     Rank, Rank_Points, Minutes)
attach(sample)
Main1 <- sample

#+++++++++++++++++++++++++++++++Train and Test+++++++++++++++++++++++++++++++++++++++
Main1 <- Main1[sample(nrow(Main1), replace = FALSE),]
attach(Main1)

#==========================Finding Correlations==============================
library(corrgram) 
corrgram(Main1)
cor(Main1, winner)
library(corrplot)
corrplot(Main1)

#View(Main1)

train <- Main1[sample(1:9500, replace=FALSE),]
test <- Main1[sample(9501:11784, replace=FALSE),]
#===========================SVM=============================
#Making SVM Model
library(e1071)
#Train and Test data

#train <- Main[sample(1:9500, 9500, replace=FALSE),]
#test <- Main[sample(9501:11784, replace=FALSE),]
#Modeling
myModel <- svm(Win~., data = train, type = "C-classification")
summary(myModel)
plot(myModel, train, Win ~ Rank)

pred <- predict(myModel, test)

SVMcomparisonTable <- data.frame(Predicted = pred, Original = test$Win)
#View(SVMcomparisonTable)
write.csv(SVMcomparisonTable,"~/Google Drive/Data Analytics/Assignment 6/DataAnalytics_A6_Chandan_Troughia_SVMComparisonTable.csv")


#=============++++++++Collision Matrix++++++++++++++++++++++++++++++++++++=========
library(caret)
predicted = c(SVMcomparisonTable$Predicted)
reference = c(SVMcomparisonTable$Original)
u = union(predicted, reference)
t = table(factor(predicted, u), factor(reference, u))
confusionMatrix(t)

mean(SVMcomparisonTable$Predicted == SVMcomparisonTable$Original)

#===================Clear Data===============================
rm(list = ls())


#===================MultiNominal Logistical===============================
#Set the directory
setwd("~/Google Drive/Data Analytics/Assignment 6")

#Import the data set FilteredDataSet.csv, sue sep = ',' because here delimiter is semi-colon
Main <-  read.table("FilteredDataSet.csv", sep=',', header=T)
#View(Main)
attach(Main)
sample <- data.frame(surface, Win, Hand, Height, Age,
                     Rank, Rank_Points, Minutes)
attach(sample)
Main1 <- sample
#Main1 <- subset(sample, Minutes > 50 & Minutes < 200)

#+++++++++++++++++++++++++++++++Train and Test+++++++++++++++++++++++++++++++++++++++
Main1 <- Main1[sample(nrow(Main1), replace = FALSE),]
attach(Main1)
#View(Main1)

train <- Main1[sample(1:9500, replace=FALSE),]
test <- Main1[sample(9501:11784, replace=FALSE),]

#+++++++++++++++++++++++++++++MultiNomial Logistic Regression+++++++++++++++++++++++++++++++++++


require(foreign)
require(nnet)
require(ggplot2)
require(reshape2)

Multi_Model <- multinom(Win ~., data = train)

summary(Multi_Model)

pred <- predict(Multi_Model, test)
MulticomparisonTable <- data.frame(Predicted = pred, Original = test$Win)
write.csv(MulticomparisonTable,"~/Google Drive/Data Analytics/Assignment 6/MultiNomial_comparisonTable.csv")

#=============++++++++Collision Matrix++++++++++++++++++++++++++++++++++++=========
library(caret)
predicted = c(MulticomparisonTable$Predicted)
reference = c(MulticomparisonTable$Original)
u = union(predicted, reference)
t = table(factor(predicted, u), factor(reference, u))
confusionMatrix(t)

mean(MulticomparisonTable$Predicted == MulticomparisonTable$Original)

#=======================Clear Data=====================================
rm(list = ls())

#=======================Random Forest=====================================
#Set the directory
setwd("~/Google Drive/Data Analytics/Assignment 6")

#Import the data set FilteredDataSet.csv, sue sep = ',' because here delimiter is semi-colon
Main <-  read.table("FilteredDataSet.csv", sep=',', header=T)
#View(Main)
attach(Main)
sample <- data.frame(surface, Win, Hand, Height, Age,
                     Rank, Rank_Points, Minutes)
attach(sample)
Main1 <- sample
#Main1 <- subset(sample, Minutes > 50 & Minutes < 200)

#+++++++++++++++++++++++++++++++Train and Test+++++++++++++++++++++++++++++++++++++++
Main1 <- Main1[sample(nrow(Main1), replace = FALSE),]
attach(Main1)
#View(Main1)

train <- Main1[sample(1:9500, replace=FALSE),]
test <- Main1[sample(9501:11784, replace=FALSE),]


#-------------------------------Random Forest Modelling--------------------------------------------
library(randomForest)  
library(e1071)  
library(caret)  
library(ggplot2)

RFModel <- randomForest(Win ~ ., data = train, ntree = 1000)
RFModel
#for importance of variables
#varImpPlot(RFModel)
#For patrial plots
#partialPlot(RFModel, train, Rank, "Yes") 

#summary(RFModel)
pred <- predict(RFModel, test)
RFComparisonTable <- data.frame(Predicted = pred, Original = test$Win)
#View(RFComparisonTable)
write.csv(RFComparisonTable,"~/Google Drive/Data Analytics/Assignment 6/RandomForest_comparisonTable.csv")

#------------------------------Confusion Matrix-----------------------------------------
library(caret)
predicted = c(RFComparisonTable$Predicted)
reference = c(RFComparisonTable$Original)
u = union(predicted, reference)
t = table(factor(predicted, u), factor(reference, u))
confusionMatrix(t)

mean(RFComparisonTable$Predicted == RFComparisonTable$Original)


#===========================Clean Data========================================
rm(list = ls())

#==========================Naive Bayes========================================
#Set the directory
setwd("~/Google Drive/Data Analytics/Assignment 6")

#Import the data set FilteredDataSet.csv, sue sep = ',' because here delimiter is semi-colon
Main <-  read.table("FilteredDataSet.csv", sep=',', header=T)
#View(Main)
attach(Main)
sample <- data.frame(surface, Win, Hand, Height, Age,
                     Rank, Rank_Points, Minutes)
attach(sample)
Main1 <- sample
#Main1 <- subset(sample, Minutes > 50 & Minutes < 200)

#+++++++++++++++++++++++++++++++Train and Test+++++++++++++++++++++++++++++++++++++++
Main1 <- Main1[sample(nrow(Main1), replace = FALSE),]
attach(Main1)
#View(Main1)

train <- Main1[sample(1:9500, replace=FALSE),]
test <- Main1[sample(9501:11784, replace=FALSE),]
#-------------------------------naiveBayes--------------------------------------------
library(e1071)
NBModel <- naiveBayes(Win ~ ., data = train)

pred <- predict(NBModel, test)
NBComparisonTable <- data.frame(Predicted = pred, Original = test$Win)
#View(NBComparisonTable)
write.csv(NBComparisonTable,"~/Google Drive/Data Analytics/Assignment 6/NaiveBayes_comparisonTable.csv")

#-------------------------Confusion Matrix---------------------------------------------
library(caret)
predicted = c(NBComparisonTable$Predicted)
reference = c(NBComparisonTable$Original)
u = union(predicted, reference)
t = table(factor(predicted, u), factor(reference, u))
confusionMatrix(t)

mean(NBComparisonTable$Predicted == NBComparisonTable$Original)

#====================Clean Data=============================
rm(list = ls())

#====================Linear Model=============================
#Set the directory
setwd("~/Google Drive/Data Analytics/Assignment 6")

#Import the data set FilteredDataSet.csv, sue sep = ',' because here delimiter is semi-colon
Main <-  read.table("FilteredDataSet.csv", sep=',', header=T)
#View(Main)
Main1 <- data.frame(Main$surface, Win = as.numeric(Main$Win), Hand = as.numeric(Main$Hand), Main$Height, Main$Age,
                    Main$Rank, Main$Rank_Points, Main$Minutes)

#==================Right = 2, Left = 1 and Yes = 2, No = 1==================================
Main1 <- Main1[sample(nrow(Main1), replace = FALSE),]
attach(Main1)
View(Main1)

train <- Main1[sample(1:9500, 9500, replace=FALSE),]
test <- Main1[sample(9501:11784, replace=FALSE),]


#================Modeling======================
my_LM_Model <- lm(Win ~., data = train)
summary(my_LM_Model)

pred <- predict(my_LM_Model, test)

LMcomparisonTable <- data.frame(Predicted = pred, Original = test$Win)
View(LMcomparisonTable)
write.csv(LMcomparisonTable,"~/Google Drive/Data Analytics/Assignment 6/LMComparisonTable.csv")

#====================Clear Data==========================
rm(list = ls())
